import { H, W } from './config';
import { Palette } from './palette';
import { TAU, css, hash, mix, mod } from './util';

type LayerKey = 'l1' | 'l2' | 'l3' | 'l4';

interface Layer {
  par: number;
  base: number;
  amp: number;
  f1: number;
  f2: number;
  f3: number;
  p1: number;
  p2: number;
  p3: number;
  ridge: boolean;
  key: LayerKey;
  featScale: number;
  featProb: number;
}

const LAYERS: Layer[] = [
  { par: 0.04, base: 505, amp: 72, f1: 0.0052, f2: 0.011, f3: 0.023, p1: 0.4, p2: 1.7, p3: 2.9, ridge: true, key: 'l1', featScale: 0.62, featProb: 0.42 },
  { par: 0.09, base: 548, amp: 56, f1: 0.0041, f2: 0.0093, f3: 0.019, p1: 2.2, p2: 0.3, p3: 1.1, ridge: false, key: 'l2', featScale: 0.8, featProb: 0.42 },
  { par: 0.17, base: 592, amp: 44, f1: 0.0036, f2: 0.0081, f3: 0.017, p1: 4.1, p2: 2.6, p3: 0.2, ridge: false, key: 'l3', featScale: 1.0, featProb: 0.34 },
  { par: 0.3, base: 630, amp: 34, f1: 0.0031, f2: 0.0072, f3: 0.015, p1: 1.3, p2: 3.7, p3: 2.2, ridge: false, key: 'l4', featScale: 1.2, featProb: 0.26 },
];

function layerY(L: Layer, wx: number, camY: number): number {
  const a = L.ridge ? (0.5 - Math.abs(Math.sin(wx * L.f1 + L.p1))) * 2 : Math.sin(wx * L.f1 + L.p1);
  const h = 0.55 * a + 0.3 * Math.sin(wx * L.f2 + L.p2) + 0.15 * Math.sin(wx * L.f3 + L.p3);
  return L.base - L.amp * h - camY * L.par * 0.6;
}

const STARS = Array.from({ length: 90 }, (_, i) => ({
  x: hash(i * 3.1 + 1) * W,
  y: hash(i * 7.7 + 2) * H * 0.56,
  s: hash(i * 9.1 + 3) > 0.88 ? 2 : 1.2,
  b: 0.3 + 0.7 * hash(i * 5.3 + 4),
  r: 1 + hash(i * 1.3 + 5) * 2,
}));

function drawFeature(ctx: CanvasRenderingContext2D, type: number, x: number, y: number, sc: number) {
  ctx.beginPath();
  if (type === 0) {
    // piramida
    const w = 150 * sc;
    const h = 72 * sc;
    ctx.moveTo(x - w / 2, y + 22);
    ctx.lineTo(x - w * 0.02, y - h);
    ctx.lineTo(x + w * 0.04, y - h);
    ctx.lineTo(x + w / 2, y + 22);
  } else if (type === 1) {
    // obelisk
    const w = 15 * sc;
    const h = 120 * sc;
    ctx.moveTo(x - w / 2, y + 22);
    ctx.lineTo(x - w * 0.36, y - h);
    ctx.lineTo(x, y - h - 12 * sc);
    ctx.lineTo(x + w * 0.36, y - h);
    ctx.lineTo(x + w / 2, y + 22);
  } else if (type === 2) {
    // gerbang reruntuhan
    const pw = 12 * sc;
    const ph = 84 * sc;
    const gap = 46 * sc;
    ctx.rect(x - gap / 2 - pw, y - ph, pw, ph + 22);
    ctx.rect(x + gap / 2, y - ph, pw, ph + 22);
    ctx.rect(x - gap / 2 - pw - 8 * sc, y - ph - 13 * sc, gap + pw * 2 + 16 * sc, 13 * sc);
  } else {
    // menara bertingkat
    ctx.rect(x - 30 * sc, y - 28 * sc, 60 * sc, 50 * sc);
    ctx.rect(x - 22 * sc, y - 54 * sc, 44 * sc, 26 * sc);
    ctx.rect(x - 14 * sc, y - 78 * sc, 28 * sc, 24 * sc);
    ctx.moveTo(x - 14 * sc, y - 78 * sc);
    ctx.lineTo(x, y - 104 * sc);
    ctx.lineTo(x + 14 * sc, y - 78 * sc);
  }
  ctx.fill();
}

export function drawBackground(
  ctx: CanvasRenderingContext2D,
  pal: Palette,
  camX: number,
  camY: number,
  time: number,
  boost: number,
  speed: number,
) {
  const c = pal.c;

  // ---- Langit ----
  const sky = ctx.createLinearGradient(0, 0, 0, H * 0.78);
  sky.addColorStop(0, css(c.skyTop));
  sky.addColorStop(0.5, css(c.skyMid));
  sky.addColorStop(1, css(c.skyBot));
  ctx.fillStyle = sky;
  ctx.fillRect(-40, -40, W + 80, H + 80);

  // ---- Bintang ----
  if (pal.stars > 0.02) {
    for (let i = 0; i < STARS.length; i++) {
      const s = STARS[i];
      const x = mod(s.x - camX * 0.01, W);
      const tw = 0.55 + 0.45 * Math.sin(time * s.r + i);
      const fadeY = 1 - s.y / (H * 0.62);
      ctx.fillStyle = `rgba(255,255,255,${(pal.stars * tw * s.b * fadeY).toFixed(3)})`;
      ctx.fillRect(x, s.y, s.s, s.s);
    }
  }

  // ---- Matahari / bulan ----
  const sx = pal.sunX * W;
  const sy = pal.sunY * H - camY * 0.03;
  const r = pal.sunR;
  const glow = ctx.createRadialGradient(sx, sy, r * 0.6, sx, sy, r * 6.2);
  glow.addColorStop(0, css(c.glow, 0.8));
  glow.addColorStop(0.3, css(c.glow, 0.28));
  glow.addColorStop(1, css(c.glow, 0));
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, W, H);
  ctx.strokeStyle = css(c.sun, 0.18);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(sx, sy, r * 1.38, 0, TAU);
  ctx.stroke();
  ctx.fillStyle = css(c.sun);
  ctx.beginPath();
  ctx.arc(sx, sy, r, 0, TAU);
  ctx.fill();
  if (pal.moon > 0.05) {
    ctx.fillStyle = css(c.glow, 0.22 * pal.moon);
    ctx.beginPath();
    ctx.arc(sx - r * 0.3, sy - r * 0.2, r * 0.22, 0, TAU);
    ctx.arc(sx + r * 0.32, sy + r * 0.28, r * 0.15, 0, TAU);
    ctx.arc(sx + r * 0.1, sy - r * 0.5, r * 0.1, 0, TAU);
    ctx.fill();
  }

  // ---- Awan panjang tipis ----
  const cloudCol = mix(c.skyBot, c.sun, 0.35);
  const cloudShade = mix(c.skyMid, c.l1, 0.5);
  for (let i = 0; i < 7; i++) {
    const w = 170 + hash(i * 2.9) * 250;
    const h = 8 + hash(i * 8.3) * 12;
    const par = 0.03 + hash(i * 1.7) * 0.05;
    const drift = 5 + hash(i * 4.1) * 9;
    const x = mod(hash(i * 13.3) * (W + 700) - camX * par - time * drift, W + 700) - 350;
    const y = 80 + hash(i * 5.1) * 330 - camY * 0.02;
    ctx.fillStyle = css(cloudShade, 0.16);
    ctx.beginPath();
    ctx.ellipse(x + 6, y + h * 0.7, w / 2, h * 0.8, 0, 0, TAU);
    ctx.fill();
    ctx.fillStyle = css(cloudCol, 0.3);
    ctx.beginPath();
    ctx.ellipse(x, y, w / 2, h, 0, 0, TAU);
    ctx.ellipse(x + w * 0.12, y - h * 0.55, w * 0.3, h * 0.8, 0, 0, TAU);
    ctx.fill();
  }

  // ---- Burung ----
  ctx.strokeStyle = css(c.obs, 0.5);
  ctx.lineWidth = 1.8;
  ctx.lineCap = 'round';
  for (let f = 0; f < 3; f++) {
    const fx = mod(f * 330 - camX * 0.12 + time * (30 + f * 6) + f * 90, W + 500) - 160;
    const fy = 150 + f * 85 + 18 * Math.sin(time * 0.3 + f) - camY * 0.05;
    for (let k = 0; k < 5; k++) {
      const bx = fx + k * 24 - (k % 2) * 6;
      const by = fy + Math.abs(k - 2) * 13 + Math.sin(time * 1.7 + k + f) * 3;
      const wing = Math.sin(time * 7 + k * 1.3 + f * 2) * 5;
      ctx.beginPath();
      ctx.moveTo(bx - 9, by - 3 + wing);
      ctx.quadraticCurveTo(bx - 4, by - 5 - wing, bx, by);
      ctx.quadraticCurveTo(bx + 4, by - 5 - wing, bx + 9, by - 3 + wing);
      ctx.stroke();
    }
  }

  // ---- Lapisan pegunungan / bukit pasir ----
  for (let li = 0; li < LAYERS.length; li++) {
    const L = LAYERS[li];
    const col = c[L.key];
    const offset = camX * L.par;

    // Fitur siluet (piramida, obelisk, gerbang, menara) — digambar sebelum isian lapisan
    const cellW = 640;
    const first = Math.floor((offset - 120) / cellW);
    const last = Math.floor((offset + W + 120) / cellW);
    ctx.fillStyle = css(col);
    for (let ci = first; ci <= last; ci++) {
      if (hash(ci * 1.37 + li * 19.1) > L.featProb) continue;
      const wx = ci * cellW + hash(ci * 3.3 + li * 7.7) * cellW * 0.8;
      const fxs = wx - offset;
      const fy = layerY(L, wx, camY);
      const type = Math.floor(hash(ci * 5.5 + li * 3.3) * 4);
      drawFeature(ctx, type, fxs, fy, L.featScale);
    }

    // Isian lapisan dengan kabut halus ke bawah
    const top = L.base - L.amp - 30;
    const g = ctx.createLinearGradient(0, top, 0, L.base + 280);
    g.addColorStop(0, css(col));
    g.addColorStop(1, css(mix(col, c.haze, 0.7)));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(-12, H + 30);
    for (let x = -12; x <= W + 12; x += 10) {
      ctx.lineTo(x, layerY(L, x + offset, camY));
    }
    ctx.lineTo(W + 12, H + 30);
    ctx.closePath();
    ctx.fill();

    // Pita angin tipis di antara lapisan
    if (li === 1 || li === 2) {
      ctx.strokeStyle = css(c.sun, 0.07);
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let x = -12; x <= W + 12; x += 10) {
        const y = layerY(L, x + offset, camY) + 26 + 5 * Math.sin((x + offset) * 0.02);
        if (x === -12) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  }

  // ---- Pita angin (terasa kecepatan) ----
  const sf = Math.min(1, speed / 700);
  for (let i = 0; i < 12; i++) {
    const y = 130 + hash(i * 6.1) * 420;
    const len = 90 + hash(i * 2.3) * 160;
    const par = 1.0 + hash(i * 8.9) * 0.9;
    const x = mod(hash(i * 3.7) * (W + 500) - camX * par, W + 500) - 250;
    const a = (0.06 + 0.1 * hash(i * 4.3)) * (0.5 + sf) + boost * 0.08;
    ctx.strokeStyle = css(c.sun, a);
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.quadraticCurveTo(x + len * 0.5, y - 10 - 8 * Math.sin(time + i), x + len, y);
    ctx.stroke();
  }
}
